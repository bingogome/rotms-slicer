var searchData=
[
  ['quat2mat_119',['quat2mat',['../d2/d17/namespaceMedImgPlanLib_1_1UtilCalculations.html#a36749aea44239b41b527a5f6017b916a',1,'MedImgPlanLib.UtilCalculations.quat2mat()'],['../df/d24/namespaceTargetVisualizationLib_1_1UtilCalculations.html#ae6a77b52da288d43921f5c665cbfa59f',1,'TargetVisualizationLib.UtilCalculations.quat2mat()']]]
];
