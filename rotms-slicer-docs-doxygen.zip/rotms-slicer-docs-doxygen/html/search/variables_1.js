var searchData=
[
  ['logic_353',['logic',['../de/dda/classMedImgPlan_1_1MedImgPlanWidget.html#a3f3ab9059ed03b83b3e2270ef3b127ab',1,'MedImgPlan.MedImgPlanWidget.logic()'],['../d6/da2/classRobotControl_1_1RobotControlWidget.html#a9600935b15c2864ba8c8c8bca04a92bc',1,'RobotControl.RobotControlWidget.logic()'],['../da/d0d/classSlicerTestExample_1_1SlicerTestExampleWidget.html#af81757addce20298d23bb352cfd36212',1,'SlicerTestExample.SlicerTestExampleWidget.logic()'],['../d6/d7a/classTargetVisualization_1_1TargetVisualizationWidget.html#a172e7a4b63b3f6217160397797ceb3cc',1,'TargetVisualization.TargetVisualizationWidget.logic()']]]
];
