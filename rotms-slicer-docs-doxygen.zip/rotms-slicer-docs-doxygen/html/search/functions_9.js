var searchData=
[
  ['normvec3_235',['normvec3',['../d2/d17/namespaceMedImgPlanLib_1_1UtilCalculations.html#af1139f32a4e639e75d66fcdf6af4ecf2',1,'MedImgPlanLib.UtilCalculations.normvec3()'],['../df/d24/namespaceTargetVisualizationLib_1_1UtilCalculations.html#a5bd85d2d9f16cab1494c42b8d6c474f8',1,'TargetVisualizationLib.UtilCalculations.normvec3()']]]
];
