var searchData=
[
  ['mat2quat_234',['mat2quat',['../d2/d17/namespaceMedImgPlanLib_1_1UtilCalculations.html#a62156260db1d0c391cd304a9575bc5c6',1,'MedImgPlanLib.UtilCalculations.mat2quat()'],['../df/d24/namespaceTargetVisualizationLib_1_1UtilCalculations.html#a2a7d61602036d0ec58e4282457ed431b',1,'TargetVisualizationLib.UtilCalculations.mat2quat()']]]
];
